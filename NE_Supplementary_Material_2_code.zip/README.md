# How much can a battery management system know about its state-of-health error without capacity labels? — reproduction code

Reproduces every number, table and figure of the Next Energy research article and its Supplementary Material.

## Run
```
pip install -r requirements.txt
bash run_all.sh            # ~75 min on 2 CPUs; MONO_QUICK=1 gives a fast smoke test
```
Or open `SOH_label_free_Colab.ipynb` in Google Colab and run all cells.
Step 01 clones the public processed data (github.com/wang-fujin/PINN4SOH, ~265 MB, pinned to commit cc3cc50) into `data/`.
`data/GMP.csv` (Mendeley Data doi:10.17632/k675pxrd83.2) is regenerated from its published generator if absent.
`data/nasa_cycle_features.csv` holds cycle-level NASA B0005/6/7/18 features (Saha & Goebel 2007).

Article figures are written to `figures/NextEnergy/` (Figure_1 ... Figure_8, Figure_S1 ... Figure_S3, Graphical_abstract);
article tables to `outputs/tables/` (Table4 ... Table9b, TableS1 ... TableS11).

| Script | Produces | Article |
|---|---|---|
| common.py | data loading (pinned commit), projection, certificate, provenance | Sections 2.1, 2.4 |
| 01_lodo.py | predictions and per-cell errors of the six main configurations | Fig. 2, Table 4 |
| 14_strong.py | tuned GBR, all-cycle GBR, 1D-CNN, PINN (deployable and published scaling) | Table 3, Fig. 2, Table 4 |
| 02_certificate.py | offline and online certificate | Table 4, Table S1, Fig. 3 |
| 03_signals.py | label-free warning signals | Table 5, Fig. S2 |
| 04_meta.py | meta-model and split conformal bound | Table 6 |
| 05_checks.py | offline check placements | Table S4, Fig. S1 |
| 06_controls.py | GMP injection and surface, NASA cells | Fig. 4, Table S2 |
| 09_reliability.py | seeds, offsets, domain bootstrap | Table S3, Fig. S3 |
| 10_explain.py | TreeSHAP importance and prediction shift | Table 8, Fig. 7a |
| 11_generalize.py | leave-one-dataset-out, number of training domains | Table 9, Fig. 8 |
| 15_stats.py | domain-level Wilcoxon, mixed models, cluster bootstrap, Holm | Tables 4, S1, S4 |
| 16_checks_causal.py | causal check schedules, alarm curve | Table 7, Fig. 6, Table S5 |
| 17_conformal.py | split, weighted, group, hierarchical conformal | Table 6, Fig. 5, Table S10 |
| 18_xai_error.py | error-centred SHAP decomposition, W null, disjoint halves | Table 8, Fig. 7b, Table S11 |
| 19_diag.py | provenance, nominal-capacity SOH, MLP diagnostics, AR(1) surface | Tables S6, S7, S9, Fig. 4d |
| 07_figures.py, 12_figures_trends.py | data figures | Figs. 2-8, S1-S3 |
| 13_tables.py | outputs/tables/*.csv and all_tables.html | Tables 4-9, S1-S11 |
| 08_workflow.py | study-design figure | Fig. 1 |
| 20_nextenergy_assets.py | figures in article numbering, graphical abstract (run last) | Figs. 1-8, S1-S3, graphical abstract |

Random seed 0 throughout. Tested with Python 3.13, scikit-learn 1.9, NumPy 2.5, pandas 3.0, SciPy 1.18, SHAP 0.54, statsmodels and JAX (CPU).
