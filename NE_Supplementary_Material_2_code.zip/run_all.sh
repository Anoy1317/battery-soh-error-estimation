#!/usr/bin/env bash
# Reproduce every table and figure of the Next Energy article and its Supplementary Material (about 75 minutes on 2 CPUs; step 14 takes about 50 of them).
# MONO_QUICK=1 bash run_all.sh gives a fast smoke test on fewer configurations and domains.
set -eo pipefail
cd "$(dirname "$0")"
export PYTHONWARNINGS=ignore
for s in "01_lodo" "14_strong all" "02_certificate" "03_signals" "04_meta" "05_checks" "06_controls" "09_reliability" \
         "10_explain" "11_generalize" "15_stats" "16_checks_causal" "17_conformal" "18_xai_error" "19_diag" \
         "07_figures" "12_figures_trends" "13_tables" "08_workflow" "20_nextenergy_assets"; do
  set -- $s
  echo "=== $1 ${2:-}"
  python3 -u "$1.py" ${2:-}
done
echo "All outputs in outputs/ (article tables in outputs/tables/), article figures in figures/NextEnergy/"
